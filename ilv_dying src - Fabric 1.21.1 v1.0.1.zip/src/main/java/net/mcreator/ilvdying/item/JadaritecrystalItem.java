package net.mcreator.ilvdying.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class JadaritecrystalItem extends Item {
	public JadaritecrystalItem(Item.Properties properties) {
		super(properties.fireResistant());
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}