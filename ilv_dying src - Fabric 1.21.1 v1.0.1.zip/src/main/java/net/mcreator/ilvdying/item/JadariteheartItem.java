package net.mcreator.ilvdying.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.network.chat.Component;

import net.mcreator.ilvdying.procedures.JadaritecrystalJogadorTerminarDeUsarOItemProcedure;

import java.util.List;

public class JadariteheartItem extends Item {
	public JadariteheartItem(Item.Properties properties) {
		super(properties.stacksTo(1).fireResistant().food(new FoodProperties.Builder().nutrition(0).saturationModifier(0f).alwaysEdible().build()));
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
		super.appendHoverText(itemstack, context, tooltip, flag);
		tooltip.add(Component.translatable("item.ilv_dying.jadariteheart.description_0"));
	}

	@Override
	public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
		ItemStack retval = super.finishUsingItem(itemstack, world, entity);
		JadaritecrystalJogadorTerminarDeUsarOItemProcedure.execute(entity, itemstack);
		return retval;
	}
}   