/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ilvdying.init;

import net.mcreator.ilvdying.procedures.KilllootbossProcedure;
import net.mcreator.ilvdying.procedures.KilllootProcedure;
import net.mcreator.ilvdying.procedures.DeathlooseProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class IlvDyingModProcedures {
	public static void load() {
		new KilllootProcedure();
		new KilllootbossProcedure();
		new DeathlooseProcedure();
	}
}