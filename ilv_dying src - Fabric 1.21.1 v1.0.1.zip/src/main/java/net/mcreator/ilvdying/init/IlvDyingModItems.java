/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ilvdying.init;

import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.ilvdying.item.JadariteheartItem;
import net.mcreator.ilvdying.item.JadaritecrystalItem;
import net.mcreator.ilvdying.IlvDyingMod;

import java.util.function.Function;

public class IlvDyingModItems {
	public static Item JADARITECRYSTAL;
	public static Item JADARITEHEART;

	public static void load() {
		JADARITECRYSTAL = register("jadaritecrystal", JadaritecrystalItem::new);
		JADARITEHEART = register("jadariteheart", JadariteheartItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> I register(String name, Function<Item.Properties, ? extends I> supplier) {
		return (I) Registry.register(BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath(IlvDyingMod.MODID, name), supplier.apply(new Item.Properties()));
	}
}