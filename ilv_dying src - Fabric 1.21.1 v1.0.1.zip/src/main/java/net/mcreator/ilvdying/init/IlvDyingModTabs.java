/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ilvdying.init;

import net.minecraft.world.item.CreativeModeTabs;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

public class IlvDyingModTabs {
	public static void load() {
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(tabData -> {
			tabData.accept(IlvDyingModItems.JADARITECRYSTAL);
			tabData.accept(IlvDyingModItems.JADARITEHEART);
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(tabData -> {
			tabData.accept(IlvDyingModItems.JADARITEHEART);
		});
	}
}