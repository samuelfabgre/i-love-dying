/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ilv_dying.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.Item;

import net.mcreator.ilv_dying.item.JadariteheartItem;
import net.mcreator.ilv_dying.item.JadaritecrystalItem;
import net.mcreator.ilv_dying.IlvDyingMod;

public class IlvDyingModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(IlvDyingMod.MODID);
	public static final DeferredItem<Item> JADARITECRYSTAL;
	public static final DeferredItem<Item> JADARITEHEART;
	static {
		JADARITECRYSTAL = REGISTRY.register("jadaritecrystal", JadaritecrystalItem::new);
		JADARITEHEART = REGISTRY.register("jadariteheart", JadariteheartItem::new);
	}
	// Start of user code block custom items
	// End of user code block custom items
}