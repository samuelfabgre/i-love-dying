/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ilvdying.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.ilvdying.item.JadariteheartItem;
import net.mcreator.ilvdying.item.JadaritecrystalItem;
import net.mcreator.ilvdying.IlvDyingMod;

public class IlvDyingModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, IlvDyingMod.MODID);
	public static final RegistryObject<Item> JADARITECRYSTAL;
	public static final RegistryObject<Item> JADARITEHEART;
	static {
		JADARITECRYSTAL = REGISTRY.register("jadaritecrystal", JadaritecrystalItem::new);
		JADARITEHEART = REGISTRY.register("jadariteheart", JadariteheartItem::new);
	}
	// Start of user code block custom items
	// End of user code block custom items
}