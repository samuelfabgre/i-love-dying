package net.mcreator.ilvdying.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import java.util.UUID;

public class JadariteheartJogadorTerminarDeUsarOItemProcedure {
    private static final UUID HEALTH_MODIFIER_UUID = UUID.fromString("a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d");

    public static void execute(Entity entity, ItemStack itemstack) {
        if (entity == null)
            return;

        if (entity instanceof LivingEntity livingEntity) {
            AttributeInstance maxHealthAttr = livingEntity.getAttribute(Attributes.MAX_HEALTH);

            if (maxHealthAttr != null) {
                AttributeModifier existingModifier = maxHealthAttr.getModifier(HEALTH_MODIFIER_UUID);
                double currentBonus = (existingModifier != null) ? existingModifier.getAmount() : 0.0;

                maxHealthAttr.removeModifier(HEALTH_MODIFIER_UUID);

                double newBonus = currentBonus + 2.0;

                AttributeModifier newModifier = new AttributeModifier(
                    HEALTH_MODIFIER_UUID,
                    "ilvdying_health_bonus",
                    newBonus,
                    AttributeModifier.Operation.ADDITION
                );

                maxHealthAttr.addPermanentModifier(newModifier);
                livingEntity.setHealth(livingEntity.getHealth() + 2.0f);
            }
        }

        itemstack.shrink(1);
    }
}