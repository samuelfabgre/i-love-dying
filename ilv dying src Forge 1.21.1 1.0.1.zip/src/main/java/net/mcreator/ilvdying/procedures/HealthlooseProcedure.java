package net.mcreator.ilvdying.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import java.util.UUID;

@Mod.EventBusSubscriber
public class HealthlooseProcedure {

    private static final UUID HEALTH_MODIFIER_UUID = UUID.fromString("a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d");

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        if (event.isWasDeath()) {
            AttributeInstance oldAttr = event.getOriginal().getAttribute(Attributes.MAX_HEALTH);
            AttributeInstance newAttr = event.getEntity().getAttribute(Attributes.MAX_HEALTH);

            if (oldAttr != null && newAttr != null) {
                AttributeModifier oldModifier = oldAttr.getModifier(HEALTH_MODIFIER_UUID);
                if (oldModifier != null) {
                    newAttr.removeModifier(HEALTH_MODIFIER_UUID);
                    newAttr.addPermanentModifier(new AttributeModifier(
                        HEALTH_MODIFIER_UUID,
                        "ilvdying_health_bonus",
                        oldModifier.getAmount(),
                        AttributeModifier.Operation.ADDITION
                    ));
                }
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerRespawned(PlayerEvent.PlayerRespawnEvent event) {
        Entity entity = event.getEntity();
        if (entity == null)
            return;

        if (entity instanceof LivingEntity livingEntity) {
            AttributeInstance maxHealthAttr = livingEntity.getAttribute(Attributes.MAX_HEALTH);

            if (maxHealthAttr != null) {
                AttributeModifier existingModifier = maxHealthAttr.getModifier(HEALTH_MODIFIER_UUID);
                
                double currentBonus = (existingModifier != null) ? existingModifier.getAmount() : 0.0;
                double currentMaxHealth = 20.0 + currentBonus;

                maxHealthAttr.removeModifier(HEALTH_MODIFIER_UUID);

                double newBonus = currentBonus;
                
                if (currentMaxHealth > 6.0) {
                    newBonus = currentBonus - 2.0;
                    if (20.0 + newBonus < 6.0) {
                        newBonus = 6.0 - 20.0;
                    }
                }

                AttributeModifier newModifier = new AttributeModifier(
                    HEALTH_MODIFIER_UUID,
                    "ilvdying_health_bonus",
                    newBonus,
                    AttributeModifier.Operation.ADDITION
                );

                maxHealthAttr.addPermanentModifier(newModifier);
                
                livingEntity.setHealth(livingEntity.getMaxHealth());
            }
        }
    }
}