package net.mcreator.ilvdying.item;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;

import net.mcreator.ilvdying.procedures.JadariteheartJogadorTerminarDeUsarOItemProcedure;

public class JadariteheartItem extends Item {
    public JadariteheartItem() {
        super(new Item.Properties()
                .stacksTo(1)
                .fireResistant()
                .food((new FoodProperties.Builder())
                        .nutrition(0)
                        .saturationMod(0f)
                        .alwaysEat()
                        .build()));
    }

    @Override
    public UseAnim getUseAnimation(ItemStack itemstack) {
        return UseAnim.EAT;
    }

    @Override
    public int getUseDuration(ItemStack itemstack) {
        return 32;
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public boolean isFoil(ItemStack itemstack) {
        return true;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
        ItemStack retval = super.finishUsingItem(itemstack, world, entity);

        JadariteheartJogadorTerminarDeUsarOItemProcedure.execute(entity, itemstack);
        
        return retval;
    }
}